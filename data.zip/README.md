# 🤖 Bot Telegram Auto Order — Diera Store

Bot Telegram otomatis untuk penjualan produk aplikasi premium, terintegrasi dengan **Pakasir** sebagai payment gateway.

---

## 🚀 Cara Menjalankan

```bash
# Masuk folder bot
cd "c:\Users\priva\OneDrive\Documents\00. STORE DATA\Bot Telegram"

# Install dependencies (hanya sekali)
npm install

# Jalankan bot
node index.js

# Atau pakai nodemon (auto-restart saat edit kode)
npx nodemon index.js
```

---

## 📂 Struktur File

```
Bot Telegram/
├── index.js          ← Entry point (jalankan ini)
├── .env              ← Konfigurasi rahasia
├── package.json
├── products.json     ← Daftar produk (edit via admin atau langsung)
├── database.json     ← Database otomatis (jangan hapus!)
├── lib/
│   ├── db.js         ← Database helper
│   ├── pakasir.js    ← Pakasir API wrapper
│   ├── qris.js       ← Generator QR image
│   └── utils.js      ← Utility functions
└── handlers/
    ├── start.js      ← /start & menu utama
    ├── products.js   ← List & detail produk
    ├── payment.js    ← Proses pembelian
    ├── deposit.js    ← Proses deposit
    ├── profile.js    ← Profil & riwayat
    └── admin.js      ← Panel admin
```

---

## 🎛️ Fitur Bot

### Untuk User:
| Tombol | Fungsi |
|--------|--------|
| 🏷️ List Produk | Lihat semua produk dengan tombol bernomor |
| 📦 Stock | Cek status stok semua produk |
| 💰 Deposit | Isi saldo via QRIS atau Virtual Account |
| 👤 Profil & Saldo | Lihat saldo dan info akun |
| 📋 Riwayat Order | Lihat 10 order terakhir |
| ℹ️ Informasi | Info toko |
| ✨ Cara Order | Panduan cara belanja |

### Untuk Admin:
| Command | Fungsi |
|---------|--------|
| `/admin` | Buka panel admin |
| `/kirim [userId] [orderId] [detail]` | Kirim detail produk ke user |

### Panel Admin:
- 📦 Tambah / lihat produk
- 🛒 Lihat semua order
- 👥 Lihat semua user
- 💰 Tambah saldo manual ke user
- 📢 Broadcast pesan ke semua user

---

## 💳 Metode Pembayaran (Deposit & Beli)

| Metode | Keterangan |
|--------|-----------|
| 📱 QRIS | Scan QR dengan GoPay/OVO/Dana/M-Banking |
| 🏦 BRI VA | Transfer ke nomor Virtual Account BRI |
| 🏦 BNI VA | Transfer ke nomor Virtual Account BNI |
| 🏦 Permata VA | Transfer ke nomor Virtual Account Permata |

---

## 🌐 Webhook (QRIS otomatis)

Webhook berjalan di **port 25582**. Untuk notifikasi bayar otomatis:

1. Jalankan **ngrok** (development lokal):
   ```bash
   ngrok http 25582
   ```
2. Salin URL ngrok (contoh: `https://abc123.ngrok.io`)
3. Masuk ke dashboard Pakasir → Edit Proyek → **Webhook URL**:
   ```
   https://abc123.ngrok.io/webhook
   ```

Jika pakai VPS, gunakan IP/domain VPS langsung:
```
http://IP_VPS:25582/webhook
```

---

## 📦 Cara Tambah Produk

### Via Panel Admin Bot:
1. Kirim `/admin` ke bot
2. Tekan **📦 Kelola Produk** → **➕ Tambah Produk**
3. Ikuti instruksi bot (nama → harga → stok → deskripsi)

### Via Edit File Langsung:
Edit `products.json` dan tambahkan:
```json
{
  "id": 11,
  "nama": "Nama Produk Baru",
  "harga": 50000,
  "stok": 5,
  "kategori": "Kategori",
  "deskripsi": "Deskripsi produk",
  "cara_penggunaan": "Cara pakai",
  "akun": []
}
```

Field `"akun": []` bisa diisi dengan daftar akun yang akan dikirim otomatis saat ada order, contoh:
```json
"akun": [
  "email: user@gmail.com | pass: password123",
  "email: user2@gmail.com | pass: password456"
]
```

---

## ⚙️ Konfigurasi (.env)

```
BOT_TOKEN=...         ← Token dari BotFather
PAKASIR_PROJECT=...   ← Slug proyek Pakasir
PAKASIR_API_KEY=...   ← API Key Pakasir
WEBHOOK_PORT=25582    ← Port webhook server
ADMIN_ID=...          ← Telegram User ID admin
STORE_NAME=...        ← Nama toko
```
